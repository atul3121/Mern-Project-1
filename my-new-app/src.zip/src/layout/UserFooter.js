function UserFooter() {
  return (
    <div className="container-fluid bg-light text-center py-3">
      All rights reserved.
    </div>
  );
}

export default UserFooter;