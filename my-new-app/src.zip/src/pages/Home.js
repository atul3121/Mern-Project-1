function Home() {
    return (
        <div className="container text-center">
            <h1>Welcome to MERN Projects</h1>
        </div>
    );
}

export default Home;