import LinksDashboard from './links/LinksDashboard';

function Dashboard() {
  return (
    <>
      <LinksDashboard />
    </>
  );
}

export default Dashboard;
