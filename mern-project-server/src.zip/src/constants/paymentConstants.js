const CREDIT_PACKS = {
    10: 10,
    20: 20,
    50: 50,
    100: 100
};

module.exports = CREDIT_PACKS;